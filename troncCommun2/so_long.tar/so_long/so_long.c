/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: judetre <julien.detre.dev@gmail.com>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/27 12:14:46 by judetre           #+#    #+#             */
/*   Updated: 2024/06/29 11:47:00 by jdetre           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	check_ber_extension(char *map)
{
	char *ext;

	ext = map + ft_strlen(map) - 4;
	if (ft_strncmp(ext, ".ber", 4))
	{
		ft_printf("Error: The map isn't a .ber\n");
		exit(EXIT_FAILURE);
	}
}

int	close_window(t_win *game)
{
	ft_free_malloc2d((void **)game->map2d);
	if (game->win)
		mlx_destroy_window(game->mlx, game->win); // close window
	if (game->mlx)
	{
		mlx_destroy_display(game->mlx); //close mlx 
		free(game->mlx); // free memory
	}
	exit(game->err);
}

char **read_map(char *file)
{
	char **map2d;

	check_ber_extension(file);
	map2d = ft_recover_fd(file);
	if (!map2d)
	{
		perror("Error map");
		exit(EXIT_FAILURE);
	}
	ft_puttab2_fd(map2d, 1);
	return (map2d);
}

int	main(int argc, char *argv[])
{
	t_win	game;
	
	ft_memset(&game, 0, sizeof(t_win));
	if (argc != 2)
	{
		ft_printf("Error : Too many or too few arguments\n");
		exit(EXIT_FAILURE);
	}
	game.map2d = read_map(argv[1]);
	game.mlx = mlx_init();
	if (!game.mlx)
		close_window(&game);
	game.win = mlx_new_window(game.mlx, 800, 500, "So_long");
	if (!game.win)
		close_window(&game);
	mlx_hook(game.win, 17, 0, close_window, &game);
	mlx_loop(game.mlx);
	exit(EXIT_SUCCESS);
}
