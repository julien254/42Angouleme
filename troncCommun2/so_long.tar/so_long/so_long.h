/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: judetre <julien.detre.dev@gmail.com>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/27 12:16:15 by judetre           #+#    #+#             */
/*   Updated: 2024/06/29 10:33:30 by jdetre           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H 
# include "libft/libft.h"
# include "mlx/mlx.h"
# include <stdio.h>
# include <errno.h>

typedef struct s_win {
	void				*mlx;
	void				*win;
	int					err;
	char				**map2d;
}				t_win;

int     close_window(t_win *game);
char    **read_map(char *file);

#endif /* ifndef SO_LONG_H */
